function a() {
    let a = ["klejdi", "asdas"];
    var b = a.map(a => a.length);
    return b;

}
console.log(a())