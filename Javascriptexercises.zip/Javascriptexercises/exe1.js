function max(n1, n2) {
    if (n1 > n2)
        return n1;
    else
        return n2;
}
console.log(max(98, 10));