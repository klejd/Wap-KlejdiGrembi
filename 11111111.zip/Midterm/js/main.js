window.onload = function() {

    // read data

    var sbmt = document.getElementById("sbmt");
    sbmt.addEventListener("click", function() {


        event.preventDefault()
        let a = document.getElementById("fname").value;
        let b = document.getElementById("dob").value;
        let c = document.getElementById("middle").value
        let getd = document.getElementById("slct");
        let d = getd.options[getd.selectedIndex].text;
        let e = document.getElementById("lname").value;
        let inp = document.getElementById("inp").value;
        //read radio input
        var result = "";

        var checkbox = document.getElementsByName("isit");
        for (i = 0; i < checkbox.length; i++) {
            if (checkbox[i].checked) {
                result = checkbox[i].value;
            }
        }
        // console.log(result);

        // let f = document.getElementById("nocheck").checked;





        var display = document.getElementById("display");
        let newRow = display.insertRow(1);
        let cells1 = newRow.insertCell(0).innerHTML = inp;
        let cells2 = newRow.insertCell(1).innerHTML = a;
        let cells3 = newRow.insertCell(2).innerHTML = c;
        let cells4 = newRow.insertCell(3).innerHTML = e;
        let cells5 = newRow.insertCell(4).innerHTML = b;
        let cells6 = newRow.insertCell(5).innerHTML = d;
        let cells7 = newRow.insertCell(6);
        cells7.innerHTML = result;
        cells7.classList.add("isElder");
        //resetForm();
        let cell8 = newRow.insertCell(7).innerHTML = '<input type="submit"  value = "Delete" >';
        let cell9 = newRow.insertCell(8).innerHTML = '<input type="submit"  value = "Edit" >';
    });

    var index, table = document.getElementById('display');
    for (var i = 1; i < table.rows.length; i++) {
        table.rows[i].cells[7].onclick = function() { //col 7 has the delete button passed onclick and anonymous func
            var c = confirm("Please confirm ?");
            if (c === true) {
                index = this.parentElement.rowIndex;
                table.deleteRow(index);
            }
            //console.log(index);
        };
        const tds = this.display

    }
    var sho1 = document.getElementById("elder");
    var isHideElder = false;
    sho1.addEventListener("click", function(event) {
        isHideElder = !isHideElder;

        var e = document.getElementsByClassName('isElder');


        for (i = 0; i < e.length; i++) {
            if (e[i].textContent == "yes") {

                if (!isHideElder) {
                    e[i].parentElement.removeAttribute("style");
                } else {
                    e[i].parentElement.setAttribute("style", "display:none");
                }
            }

        }

    });
    var sho2 = document.getElementById('out');
    var ishideout = false;
    sho2.addEventListener("click", function() {
        ishideout = !ishideout;
        var abc = document.getElementsByClassName('isElder'); //table colum 6 passed a  class name
        for (i = 0; i < abc.length; i++) {
            console.log(abc[i]);
            if (abc[i].textContent == "no") {
                if (!ishideout) {
                    abc[i].parentElement.removeAttribute("style");
                } else {
                    abc[i].parentElement.setAttribute("style", "display:none");
                }
            }
        }
    });

    function resetForm() {
        let a = document.getElementById("fname").value = "";
        let b = document.getElementById("dob").value = "";
        let c = document.getElementById("middle").value = "";
        let getd = document.getElementById("slct");
        let d = getd.options[getd.selectedIndex].text = "";
        let e = document.getElementById("lname").value = "";
        let inp = document.getElementById("inp").value = "";
    }

    // var btnn = document.getElementsByClassName("deletebtn");

    // btnn.addEventListener("click", function() {
    //     alert("deleted");
    // });



}